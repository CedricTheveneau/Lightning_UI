# Notice

---

## Original code

### Lightning UI

**_Copyright (c) 2023 Cédric Theveneau_**

This product includes software from https://github.com/CedricTheveneau/Lightning_UI

- The use of the [Lightning UI](https://github.com/CedricTheveneau/Lightning_UI) [light](./assets/logoLight.svg)/[dark](./assets/logoDark.svg) logos and brand name are forbidden except for the owner.
- Copyright (c) 2023 [Cédric Theveneau](https://github.com/CedricTheveneau)
- Licensed under the [MIT License](https://www.tldrlegal.com/license/mit-license);
