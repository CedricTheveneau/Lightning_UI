const blogData = [
  {
    title: "My other title",
    summary: "<p>My summary.</p>",
    tags: "<span class='tag feature'>Tag 2</span>",
    date: "<p>-&nbsp;&nbsp; November 1, 2023</p>",
    content:
      "<p>My first sentence goes here</p><p>And here's a second one !</p><p>And so on...</p><br/><p>My name, my job</p>",
    img: "./assets/logoLight.svg",
  },
  {
    title: "My title",
    summary: "<p>My summary</p>",
    tags: "<span class='tag release'>Tag 1</span>",
    date: "<p>-&nbsp;&nbsp; November 1, 2023</p>",
    content:
      "<p>My first sentence goes here</p><p>And here's a second one !</p><p>And so on...</p><br/><p>My name, my job</p>",
    img: "./assets/logoLight.svg",
  },
];
